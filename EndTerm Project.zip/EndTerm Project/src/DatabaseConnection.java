import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

class DatabaseConnection {
    private static final String dbUrl = "jdbc:postgresql://localhost:1675/postgres";
    private static final String dbUsername = "postgres";
    private static final String dbPassword = "Altynai2001";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
    }
}