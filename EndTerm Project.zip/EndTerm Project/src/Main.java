import java.sql.*;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        ChoiceImp choicE = new ChoiceImp();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Show Products");
            System.out.println("2. Add Product");
            System.out.println("3. Update Product Choice");
            System.out.println("4. Delete Product");
            System.out.println("5. Exit");

            System.out.print("Enter command: ");
            int command = scanner.nextInt();

            try {
                switch (command) {
                    case 1:
                        choicE.showChoice();
                        break;
                    case 2:
                        System.out.print("Enter barcode: ");
                        String barcode = scanner.next();
                        System.out.print("Enter choice (Alua, Merey, Nobody): ");
                        String choice = scanner.next();
                        choicE.addChoice(barcode, choice);
                        break;
                    case 3:
                        System.out.print("Enter barcode: ");
                        barcode = scanner.next();
                        System.out.print("Enter new choice (Alua, Merey, Nobody): ");
                        choice = scanner.next();
                        choicE.updateChoice(barcode, choice);
                        break;
                    case 4:
                        System.out.print("Enter barcode for deletion: ");
                        barcode = scanner.next();
                        choicE.deleteChoice(barcode);
                        break;
                    case 5:
                        System.out.println("Exiting program.");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Unknown command. Please try again.");
                        break;
                }
            } catch (SQLException error) {
                System.out.println("Database error: " + error.getMessage());
            } catch (Exception error) {
                System.out.println("Error: " + error.getMessage());
            }
        }
    }
}