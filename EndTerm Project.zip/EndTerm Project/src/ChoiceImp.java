import java.sql.*;

public class ChoiceImp implements Choice {
    @Override
    public void showChoice() throws SQLException {
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM election ORDER BY barcode ASC")) {
            while (rs.next()) {
                System.out.println("Barcode: " + rs.getString("barcode") + ", Choice: " + rs.getString("choice"));
            }
        }
    }

    @Override
    public void addChoice(String barcode, String choice) throws SQLException {
        String sql = "INSERT INTO election(barcode, choice) VALUES (?, ?);";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, barcode);
            pstmt.setString(2, choice);
            pstmt.executeUpdate();
        }
    }

    @Override
    public void updateChoice(String barcode, String newChoice) throws SQLException {
        String sql = "UPDATE election SET choice = ? WHERE barcode = ?;";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newChoice);
            pstmt.setString(2, barcode);
            pstmt.executeUpdate();
        }
    }

    @Override
    public void deleteChoice(String barcode) throws SQLException {
        String sql = "DELETE FROM election WHERE barcode = ?;";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, barcode);
            pstmt.executeUpdate();
        }
    }
}