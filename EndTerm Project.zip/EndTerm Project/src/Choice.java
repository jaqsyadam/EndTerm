import java.sql.SQLException;
public interface Choice {
    void showChoice() throws SQLException;
    void addChoice(String barcode, String choice) throws SQLException;
    void updateChoice(String barcode, String newChoice) throws SQLException;
    void deleteChoice(String barcode) throws SQLException;
}